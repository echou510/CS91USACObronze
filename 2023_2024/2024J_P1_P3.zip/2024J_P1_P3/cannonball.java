import java.util.*;
import java.io.*;
public class cannonball
{
    public static void main(String[] args)throws Exception{
        //Scanner input = new Scanner(new File("cannonball2.txt"));
        Scanner input = new Scanner(System.in);
        int N= input.nextInt(), S=input.nextInt()-1; 
        int[] q = new int[N];
        int[] v = new int[N]; 
        boolean[] visited = new boolean[N]; 
        for (int i=0; i<N; i++){
           q[i] = input.nextInt(); 
           v[i] = input.nextInt(); 
        }
        int dir = 1; 
        int pow = 1; 
        int count = 0; 
        int pos = S; 
        int round = 0; 
        while (pos >=0 && pos <N && round < 5000000){
            if (q[pos]==0){
                pow += v[pos]; 
                dir *= -1; 
            }
            else if(q[pos]==1) {
               if (!visited[pos] && pow >= v[pos]){
                  count++; 
                  visited[pos] = true; 
                }
            }
            
            pos += dir * pow; 
            round++; 
        }
        System.out.println(count); 
        input.close(); 
    }
}
