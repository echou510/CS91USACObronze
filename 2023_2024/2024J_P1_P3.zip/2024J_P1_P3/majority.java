import java.util.*;
import java.io.*;
public class majority
{
    public static void main(String[] args) throws Exception{
        //Scanner input = new Scanner(new File("majority.txt"));
        Scanner input = new Scanner(System.in);
        int N = input.nextInt(); 
        //System.out.println(N);
        for (int round=0; round < N; round++){
            int M = input.nextInt(); 
            int[] h = new int[M]; 
            boolean[] good = new boolean[M+1];
            boolean found = false; 
            for (int i=0; i<M; i++) h[i] = input.nextInt(); 
            
            for (int i=0; i<M; i++){
                if (i<M-1 && h[i]==h[i+1]) { good[h[i]] = true; found = true; }
                if (i<M-2 && h[i]==h[i+2]) { good[h[i]] = true; found = true; }
            }
            
            if (!found) { System.out.println("-1"); continue; }
            boolean first = true; 
            for (int i=1; i<good.length; i++){
               if (first && good[i]) { System.out.print(i); first = false; }
               else if (good[i]) System.out.print(" "+i); 
            }
            System.out.println(); 
        }
        input.close(); 
    }
}
