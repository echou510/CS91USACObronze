import java.util.*;
import java.io.*;
public class bacteria
{
    public static void main(String[] args) throws Exception{
        //Scanner input = new Scanner(new File("test3.txt"));
        Scanner input = new Scanner(System.in);
        int N = input.nextInt(); 
        long[] a = new long[N];
        
        for (int i=0; i<N; i++) a[i] = input.nextLong(); 
        long sum =0;
        long num = 0;
        long carry = 0; 
        long diff = 0; 
        for (int round=0; round<N; round++){
            num = - (carry + diff + a[round]);
            carry = carry + diff + num; 
            diff = diff + num; 
            sum += Math.abs(num); 
        }
        
        System.out.println(sum); 
        input.close(); 
    }
}
