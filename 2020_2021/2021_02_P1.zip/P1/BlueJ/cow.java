import java.util.*;
import java.io.*;

public class cow {
    static String[] z = {
            "Rat", "Ox", "Tiger", "Rabbit", "Dragon", "Snake", "Horse", "Goat",
            "Monkey", "Rooster", "Dog", "Pig"
    };

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int N = Integer.parseInt(input.nextLine());
        Map<String, Integer> zz = new HashMap<String, Integer>();
        for (int i = 0; i < z.length; i++) {
            Integer Iobj = i;
            zz.put(z[i], Iobj);
        }

        Map<String, Integer> animal = new HashMap<String, Integer>();
        Map<String, Integer> animalZ = new HashMap<String, Integer>();

        animal.put("Bessie", 0);
        animalZ.put("Bessie", zz.get("Ox"));

        for (int i = 0; i < N; i++) {
            String line = input.nextLine();
            String[] tokens = line.split(" ");
            String to = tokens[0];
            String from = tokens[7];
            String next = tokens[3];
            String zo = tokens[4];

            // System.out.printf("%s %s %s %s\n", to, from, next, zo);

            int x = (next.equals("next")) ? 1 : -1;

            int fromYear = animal.get(from).intValue();
            int fromZodiac = animalZ.get(from);
            int toZodiac = zz.get(zo);

            animalZ.put(to, toZodiac);

            if (toZodiac < fromZodiac) {
                if (x == -1) {
                    animal.put(to, fromYear - (fromZodiac - toZodiac));
                } else {
                    animal.put(to, fromYear + (12 - (fromZodiac - toZodiac)));
                }
            } else if (toZodiac > fromZodiac) {
                if (x == -1) {
                    animal.put(to, fromYear - (12 + (fromZodiac - toZodiac)));
                } else {
                    animal.put(to, fromYear + (toZodiac - fromZodiac));
                }
            } else {
                if (x == -1) {
                    animal.put(to, fromYear - 12);
                } else {
                    animal.put(to, fromYear + 12);
                }
            }

        }

        // System.out.println();
        // for (String a : animal.keySet()) {
        // System.out.printf("Animal: %s, Year: %d\n", a, animal.get(a));
        // }
        // System.out.println();

        // for (String a : animalZ.keySet()) {
        // System.out.printf("Animal: %s, Year: %s\n", a, z[animalZ.get(a)]);
        // }
        // System.out.println("Done");
        int ee = animal.get("Elsie");
        if (ee < 0)
            ee = -ee;
        System.out.println(ee);

        input.close();
    }
}
