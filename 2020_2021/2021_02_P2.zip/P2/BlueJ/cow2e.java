import java.util.*; 
public class cow2e
{
   static int[][] v = {{-1,0}, {0, -1}, {1, 0}, {0, 1} }; 
   
   public static void main(String[] args){
       Scanner input = new Scanner(System.in);
       
       int N = input.nextInt(); 
       boolean[][] cow = new boolean[1001][1001]; 
       int[][] nb = new int[1001][1001]; 
       int comfort = 0; 
       
       for (int i=0; i<N; i++){
           int x = input.nextInt(); 
           int y = input.nextInt(); 
           //cow[x][y] = true; 
           int cc = 0; 
           for (int j=0; j<v.length; j++){  // checking the 4 neighbors
               int xn = x + v[j][0]; 
               int yn = y + v[j][1]; 
               if (xn <0 || xn >1000) continue; 
               if (yn <0 || yn >1000) continue; 
               if (!cow[xn][yn]) continue; 
               
               cc++; 
               int c = nb[xn][yn]; 

               if (c==2) comfort++; 
               if (c==3) comfort--;  
               nb[xn][yn]++; 
            }
          
           cow[x][y] = true; 
           nb[x][y]=cc; 
           if (cc==3) comfort++; 
           System.out.println(comfort); 
        }
       input.close(); 
    }
}
