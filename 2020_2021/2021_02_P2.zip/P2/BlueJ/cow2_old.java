import java.util.*; 
public class cow2_old
{
   static int[][] v = {{-1,0}, {0, -1}, {1, 0}, {0, 1} }; 
   
   //public static boolean in(int xn, int yn, int[] vx){
   // }
   public static void main(String[] args){
       //System.out.print("\f"); 
       Scanner input = new Scanner(System.in);
       
       int N = input.nextInt(); 
       boolean[][] cow = new boolean[1001][1001]; 
       int comfort = 0; 
       
       for (int i=0; i<N; i++){
           int x = input.nextInt(); 
           int y = input.nextInt(); 
           //cow[x][y] = true; 
           int cc = 0; 
           for (int j=0; j<v.length; j++){  // checking the 4 neighbors
               int xn = x + v[j][0]; 
               int yn = y + v[j][1]; 
               boolean xnin = xn >= 0 && xn <= 1000 ? true : false; 
               boolean ynin = yn >= 0 && yn <= 1000 ? true : false; 
               if (!xnin || !ynin) continue; 
               if (!cow[xn][yn]) continue; 
               cc++; 
               int c = 0; 
               for (int k =0; k<v.length; k++){
                   int xnn = xn + v[k][0]; 
                   int ynn = yn + v[k][1]; 
                   boolean xnnin = xnn >= 0 && xnn <= 1000 ? true : false; 
                   boolean ynnin = ynn >= 0 && ynn <= 1000 ? true : false; 
                   if (!xnnin || !ynnin) continue; 
                   if (cow[xnn][ynn]) c++;  
                }
               //System.out.printf("<%d, %d> = %d\n", xn, yn, c); 
               if (c==2) comfort++; 
               else if (c==3) comfort--;  
            }
           // check the current point.
          
           cow[x][y] = true; 
           if (cc==3) comfort++; 
           System.out.println(comfort); 
        }
       input.close(); 
    }
}
