
public class Pair<T extends Comparable, E extends Comparable> implements Comparable<Pair> 
{
   static int Mode = 0; 
   public T first; 
   public E second; 
   Pair(T f, E s){ this.first = f;  this.second = s; }
   
   public T getFirst(){ return first; }
   public E getSecond(){ return second; }
   public static void setMode(int m){ Mode = m; }
   public boolean equals(Object other){
       Pair<T, E> that = (Pair<T, E>) other; 
       return first.equals(that.first) && second.equals(that.second); 
    }
   
   public int compareTo(Pair that){  // compare first first, or 2nd first.    
        if (Mode == 0){
            if (this.first.compareTo(that.first) > 0) return 1; 
            else if (this.first.compareTo(that.first) <0) return -1; 
            if (this.second.compareTo(that.second) > 0) return 1; 
            else if (this.second.compareTo(that.second) <0) return -1; 
        }
        else {
            if (this.second.compareTo(that.second) > 0) return 1; 
            else if (this.second.compareTo(that.second) <0) return -1;   
            if (this.first.compareTo(that.first) > 0) return 1; 
            else if (this.first.compareTo(that.first) <0) return -1; 
        }
        return 0; 
    }
   
   public String toString(){ return "<"+first.toString() + second.toString()+">"; }
}
