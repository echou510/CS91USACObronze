import java.util.*; 
public class TestPair
{
   public static void main(String[] args){
      System.out.print("\f"); 
      Pair<String, Integer> p1 = new Pair("A", 3); 
      Pair<String, Integer> p2 = new Pair("C", 1); 
      Pair<String, Integer> p3 = new Pair("B", 2); 
      Pair<String, Integer> p4 = new Pair("A", -1); 
      Pair<String, Integer> p5 = new Pair("B", 0); 
      Pair<String, Integer> p6 = new Pair("C", 12);   
      Pair<String, Integer> p7 = new Pair("B", -3); 
      Pair<String, Integer> p8 = new Pair("C", 2); 
      Pair<String, Integer> p9 = new Pair("A", 2); 
      ArrayList<Pair<String, Integer>> alist = new ArrayList<Pair<String, Integer>>(); 
      alist.add(p1); alist.add(p2); alist.add(p3); 
      alist.add(p4); alist.add(p5); alist.add(p6); 
      alist.add(p7); alist.add(p8); alist.add(p9); 
      Pair.setMode(0);  // sort string first
      System.out.println(alist); 
      Collections.sort(alist); 
      System.out.println(alist); 
      Pair.setMode(1); // sort integer first; 
      System.out.println(alist); 
      Collections.sort(alist); 
      System.out.println(alist); 
    }
}
