import java.util.*; 
public class TestPair2
{
    static class pair extends ArrayList<Integer> implements Comparable<pair>{
       pair(int a, int b){ this.add(a); this.add(b); }
       public int compareTo(pair that){  // compare first first, or 2nd first.    
            if (this.get(0).compareTo(that.get(0)) > 0) return 1; 
            else if (this.get(0).compareTo(that.get(0)) <0) return -1; 
            if (this.get(1).compareTo(that.get(1)) > 0) return 1; 
            else if (this.get(1).compareTo(that.get(1)) <0) return -1; 
            return 0; 
        }
    }
    static class pairlist extends ArrayList<pair>{}
    public static void main(String[] args){
      pair p1 = new pair(3, 2);
      pair p2 = new pair(1, 4); 
      pair p3 = new pair(-1, 2); 
      ArrayList<pair> plist = new ArrayList<pair>(); 
      
      plist.add(p1); plist.add(p2); plist.add(p3); 
      System.out.println(plist); 
      Collections.sort(plist); 
      System.out.println(plist); 
    }
}

       /*
       pair(){}
       pair(Integer a, Integer b){
          this.add(a); this.add(b); 
        }
        */
