









/*
ID: echou511
LANG: JAVA
TASK: beads
*/
import java.io.*;
import java.util.*;
class beads {
  static ArrayList<Run> blist = new ArrayList<Run>(); 
  static class Run{
       int b, e, len; char c='w'; 
       Run(int begin, int end, char color){ b = begin; e = end; c = color; len= e-b; }
       public String toString2(){ return String.format("[%d, %d, %c, len=%d]", b, e, c, len); } 
       public String toString(){ return String.format("[%d, %d, %c]\n", b, e, c); } 
    }
  public static void main (String [] args) throws IOException {
    System.out.print("\f"); 
    Scanner     in  = new Scanner(new File("beads.in"));
    PrintWriter out = new PrintWriter(new File("beads.out")); 
    int N = Integer.parseInt(in.nextLine().trim());
    String beads = in.nextLine().trim(); 
    int max=Integer.MIN_VALUE; 
    beads += beads; 
    int s = 0; 
    int e = 1; 
    char c = beads.charAt(0);
    for (int cut = 1; cut <= beads.length(); cut++){
      if (cut == beads.length()){
           e = beads.length(); 
           Run x = new Run(s, e, c);  
           blist.add(x); 
           break; 
        }
      if (beads.charAt(cut-1) != beads.charAt(cut)){
           e = cut; 
           Run x = new Run(s, e, c);  
           s = e; 
           c = beads.charAt(cut); 
           blist.add(x); 
        }
    }

    if (blist.size()!=1) { 
        for (int cut = 1; cut< blist.size(); cut++){
           char lcolor = blist.get(cut-1).c; 
           char rcolor = blist.get(cut).c; 
           if (lcolor == 'w'){ lcolor = (rcolor == 'r') ? 'b' : 'r'; }
           if (rcolor == 'w'){ rcolor = (lcolor == 'r') ? 'b' : 'r'; }
           int left  = 0; 
           int right = 0;
           //System.out.printf("left=%c, right=%c\n", lcolor, rcolor); 
           int j=cut-1; 
           while (j>=0 && blist.get(j).c != rcolor) { left += blist.get(j).len;  j--; }
           //System.out.println(left); 
           j=cut; 
           while (j<blist.size() && blist.get(j).c != lcolor) { right += blist.get(j).len; j++;}
           if (left+right > max) max = left+right; 
           //System.out.println(left+right); 
        }
    }
    else { max = N; }
    if (max>N) max = N; 
    out.println(max); 
    out.close(); 
    in.close(); 
  }
}