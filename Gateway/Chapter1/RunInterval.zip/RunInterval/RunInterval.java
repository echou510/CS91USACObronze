import java.io.*;
import java.util.*;
public class RunInterval{
  static ArrayList<Run> blist = new ArrayList<Run>(); 
  static class Run{
       int b, e, len; char c='w'; 
       Run(int begin, int end, char color){ b = begin; e = end; c = color; len= e-b; }
       public String toString2(){ return String.format("[%d, %d, %c, len=%d]", b, e, c, len); } 
       public String toString(){ return String.format("[%d, %d, %c]\n", b, e, c); } 
    }
  public static void main (String [] args) throws IOException {
    System.out.print("\f"); 
    Scanner     in  = new Scanner(new File("beads.in"));
    PrintWriter out = new PrintWriter(new File("beads.out")); 
    int N = Integer.parseInt(in.nextLine().trim());
    String beads = in.nextLine().trim(); 
    beads += beads; 
    int s = 0; 
    int e = 1; 
    char c = beads.charAt(0);
    for (int cut = 1; cut <= beads.length(); cut++){
      if (cut == beads.length()){
           e = beads.length(); 
           Run x = new Run(s, e, c);  
           blist.add(x); 
           break; 
        }
      if (beads.charAt(cut-1) != beads.charAt(cut)){
           e = cut; 
           Run x = new Run(s, e, c);  
           s = e; 
           c = beads.charAt(cut); 
           blist.add(x); 
        }
    }
 
    for (Run x: blist){
      System.out.println(x.toString2()); 
    }
    out.close(); 
    in.close(); 
  }
}