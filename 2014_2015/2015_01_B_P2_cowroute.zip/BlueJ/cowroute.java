import java.util.*;
import java.io.*;

public class cowroute {
    static class route extends ArrayList<Integer>{}
    public static void main (String[] args) throws Exception{
        System.out.print("\f");
        Scanner input = new Scanner(new File("cowroute.in")); 
        PrintWriter out = new PrintWriter(new File("cowroute.out")); 
        int A = input.nextInt(); 
        int B = input.nextInt(); 
        int N = input.nextInt(); 
        
        route[] routes = new route[N]; 
        int[] costs = new int[N]; 
        for (int i=0; i<N; i++){
          routes[i] = new route(); 
          costs[i] = input.nextInt(); 
          int M = input.nextInt(); // M cities
          for (int j=0; j<M; j++) routes[i].add(input.nextInt()); 
          //System.out.println(routes[i]); 
        }
        
        int min = Integer.MAX_VALUE; 
        for (int i=0; i<N; i++) { 
            int a = routes[i].indexOf(A);
            int b = routes[i].indexOf(B); 
            if (costs[i]<min && a>=0 && b>=0 && a<b) { min = costs[i]; }
        }
        
        for (int i=0; i<N; i++){
           for (int j=0; j<N; j++){
               if (i==j) continue;
               int a = routes[i].indexOf(A); 
               int b = routes[j].indexOf(B); 
               if (a<0 || b<0) continue; 
               ArrayList<Integer> routeA = routes[i]; 
               ArrayList<Integer> routeB = routes[j]; 
               for (int k = a+1; k<routeA.size(); k++){
                   int cityK = routeA.get(k); 
                   int kk = routeB.indexOf(cityK); 
                   if (kk>=0 && kk<b){
                      if (costs[i]+costs[j]<min) min = costs[i]+costs[j]; 
                    }
                }
            } 
        }
        
        if (min==Integer.MAX_VALUE) min = -1; 
        out.println(min); 
        input.close(); 
        out.close(); 
    }
}
