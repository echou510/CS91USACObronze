/*
ID: tomlee1234
LANG: JAVA
TASK: angry
*/
import java.io.*;
import java.util.*;
class angry {
  public static void main (String [] args) throws IOException {
    System.out.print("\f"); 
    Scanner     input = new Scanner(new File("angry.in"));
    PrintWriter out   = new PrintWriter(new File("angry.out")); 
    int N = input.nextInt(); 
    ArrayList<Integer> a = new ArrayList<Integer>(); 
    
    for (int i=0; i<N; i++){
       a.add(input.nextInt());
    }
    
    Collections.sort(a); 
    int max =0; 
    for (int i=0; i<N; i++){
       int left = i; 
       int right = i; 
       int rp = right; 
       int rq = right; 
       int radius = 1; 
       //System.out.printf("a[%d]=%d\n", i, a.get(i)); 
       while (true){
         while (rp<=N-1 && a.get(rp) <= a.get(right)+radius) { rq = rp; rp++; }
         if (rq == right) break; else right = rq; 
         radius++; 
       }
       //System.out.printf("Right a[%d]=%d\n", i, right); 
       
       radius = 1; 
       int lp = left; 
       int lq = left; 
       while (true){
          while (lp >=0 && a.get(lp) >= a.get(left)-radius) { lq = lp; lp--; }
          if (lq == left) break; else left = lq; 
          radius++; 
        }
       //System.out.printf("Left a[%d]=%d\n", i, left); 
       int span = right-left + 1; 
       if (span > max) max = span; 
       //System.out.printf("a[%d] span=%d\n", i, span); 
    }
    out.println(max); 
    out.close(); 
    input.close(); 
  }
}